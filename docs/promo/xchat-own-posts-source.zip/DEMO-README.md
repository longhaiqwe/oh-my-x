# XChat 引用我的帖子功能示意

基于 StageShow 的 React 动画。不是实际聊天的屏幕录制，不会发送消息。

- 安装：npm ci
- 预览：node node_modules/vite/bin/vite.js playground --config playground/vite.config.ts --host 127.0.0.1 --port 5190
- 打开：http://127.0.0.1:5190/?capture=ohmyx-chat
- 源码：examples/ohmyx-chat/index.tsx 和 chat.css
- 制作与检查记录：examples/ohmyx-chat/REHEARSAL.md

导出脚本 scripts/export-demo.mjs 中的输出目录需要按本机位置调整。
