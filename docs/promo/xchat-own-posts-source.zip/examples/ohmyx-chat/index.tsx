import { FileText, Plus, Smile, Search, X, ArrowUp, MoreHorizontal, Phone, Video } from 'lucide-react'
import { Stage, Window, Row, Bar, Avatar, Field, Popover, Thread, Bubble, Stamp, type Act } from '../../kit'
import './chat.css'
type S={open:boolean;query:string;draft:string;hint:boolean}
const initial:S={open:false,query:'',draft:'',hint:false}
const link='https://x.com/longhaiqwe123/status/2119689338397352189'
async function script(a:Act<S>){
 await a.wait(900);a.mark('入口');await a.move('quote');await a.set({hint:true});await a.wait(850);
 a.mark('打开');await a.click('quote');await a.set({open:true,hint:false});await a.wait(1100);
 a.mark('搜索');await a.click('search');await a.type('query','oh-my-x',{interval:120});await a.wait(900);
 a.mark('选择');await a.click('post');await a.set({open:false,draft:link});await a.wait(2800);
 a.mark('清空草稿');await a.click('draft');await a.key('cmd+a');await a.wait(350);await a.key('backspace');await a.set({draft:'',query:''});await a.wait(500);await a.move('rest');a.mark('循环结束');await a.wait(700);
}
export default function Demo(){return <Stage<S> width={1000} height={620} compact={{below:440,width:358,height:320}} initial={initial} poster={{...initial,open:true,query:'oh-my-x'}} script={script} cursor={{at:'rest',ripple:true}} keys="bottom-left" theme="light" className="xc">
{(s,rect,layout)=>{const compact=layout==='compact';return <>
<Window url="x.com/i/chat" className="xc-window" style={{left:compact?16:24,top:compact?16:24,width:compact?326:952,height:compact?380:660}} body={{className:'xc-body','data-crop':true}}>
{!compact&&<aside className="xc-side"><h2>𝕏 <span>聊天</span></h2><div className="xc-side-search"><Search size={17}/>搜索</div><Row selected lead={<Avatar name="oh-my-x" size={38}/>} title="oh-my-x 用户群" subtitle="分享功能与使用方法" pad={12}/>{[0,1,2,3,4].map(i=><Row key={i} lead={<Avatar name={['Maya','Leo','Sam','Tao','Jane'][i]} size={36}/>} title={<Bar w={85+i*8} h={8}/>} subtitle={<Bar w={130-i*7} h={6}/>} pad={14}/>)}</aside>}
<div className="xc-chat"><header><strong>oh-my-x 用户群</strong><span><Phone size={18}/><Video size={19}/><MoreHorizontal size={22}/></span></header>
<div className="xc-thread" data-target="rest"><Thread><Stamp>今天</Stamp><Bubble from="them">刚发布的功能，链接发一下？</Bubble><Bubble from="me">我找一下刚才的帖子。</Bubble></Thread><div className="xc-feature"><FileText size={30}/><h2>在 Chat 中引用我的帖子</h2><p>点击输入框旁的图标，搜索并选择。</p></div></div>
<div className="xc-compose"><span className="xc-extra"><Plus size={23}/>{!compact&&<Smile size={23}/>}</span><div className="xc-input" data-filled={!!s.draft}><span data-target="quote" data-cursor="pointer" className="xc-quote"><FileText size={23}/></span><span className="xc-draft" data-target="draft" data-cursor="text"><span className="xc-placeholder" style={{opacity:s.draft?0:1}}>私信</span><span className="xc-value" style={{opacity:s.draft?1:0}}>{s.draft}</span></span><span className="xc-send"><ArrowUp size={19}/></span></div></div>
<div className="xc-note">{s.draft?'链接已填入，确认后发送':'空输入框按 / 也可以打开'}</div></div>
</Window>
<Popover show={s.hint} origin="bottom left" className="xc-tip" style={{left:rect('quote').x-8,top:rect('quote').y-42}}>引用我的帖子</Popover>
<div className="xc-dim" data-open={s.open}/>
<Popover show={s.open} origin="top center" className="xc-picker" style={{left:compact?24:250,top:compact?32:115,width:compact?310:500}}><div className="xc-picker-head"><div><h3>引用我的帖子</h3><p>@longhaiqwe123 · 选择一条插入</p></div><X size={21}/></div><Field value={s.query} placeholder="搜索我的帖子" focused={s.open} box={{'data-target':'search'}} className="xc-search"/><div className="xc-count">本地搜索 · 找到 2 条</div><Row className="xc-post" pad={12} data-target="post" data-cursor="pointer" lead={<FileText size={26}/>} title="oh-my-x v2.6.0 发布" subtitle="新增博主收藏、GIF 导出和复制" preview={compact?undefined:<span>收藏常看的博主，将推文中的视频导出为 GIF。</span>}/>{!compact&&<Row className="xc-post" pad={12} lead={<FileText size={26}/>} title="oh-my-x：X 网页端扩展" subtitle="界面优化 · 噪音过滤 · 创作辅助"/>}<div className="xc-picker-foot">{compact?'显示 1/2 · 选择后插入原帖链接':'从本机帖子库选择，插入原帖链接'}</div></Popover>
<div className="xc-brand">oh-my-x · 功能示意</div>
</>}}</Stage>}
